const extensionApi = typeof browser !== "undefined" ? browser : chrome;
const DEFAULT_API_BASE = "https://habit-tracker-ixsb.onrender.com";

const usernameForm = document.getElementById("usernameForm");
const usernameInput = document.getElementById("usernameInput");
const profileView = document.getElementById("profileView");
const statusMessage = document.getElementById("statusMessage");
const todayHabitsContainer = document.getElementById("todayHabits");
const openSettingsButton = document.getElementById("openSettings");
const refreshButton = document.getElementById("refreshButton");
const clearProfileButton = document.getElementById("clearProfile");
const openWebAppButton = document.getElementById("openWebApp");
const userName = document.getElementById("userName");
const userMeta = document.getElementById("userMeta");
const profileHint = document.getElementById("profileHint");
const todayLabel = document.getElementById("todayLabel");

let currentUsername = "";
const APP_TIMEZONE_OFFSET_MINUTES = 330;
const APP_TIMEZONE_OFFSET_MS = APP_TIMEZONE_OFFSET_MINUTES * 60 * 1000;

function storageGet(keys) {
  return new Promise((resolve) => extensionApi.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => extensionApi.storage.local.set(values, resolve));
}

async function getSettings() {
  const result = await storageGet(["habtrackApiBase", "habtrackLastUsername"]);

  return {
    apiBase: (result.habtrackApiBase || DEFAULT_API_BASE).replace(/\/$/, ""),
    lastUsername: result.habtrackLastUsername || "",
  };
}

function showStatus(message, tone = "info") {
  statusMessage.textContent = message;
  statusMessage.classList.remove("hidden");
  statusMessage.style.background =
    tone === "error" ? "rgba(220, 38, 38, 0.92)" : "rgba(15, 23, 42, 0.92)";
}

function clearStatus() {
  statusMessage.classList.add("hidden");
  statusMessage.textContent = "";
}

function shiftToAppTime(date = new Date()) {
  return new Date(new Date(date).getTime() + APP_TIMEZONE_OFFSET_MS);
}

async function publicRequest(path) {
  const { apiBase } = await getSettings();
  const response = await fetch(`${apiBase}${path}`);
  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    if (!response.ok) {
      throw new Error("The API did not return a valid JSON response.");
    }
  }

  if (!response.ok) {
    throw new Error(data?.message || data?.error || "Request failed");
  }

  return data;
}

function getTodayKey() {
  const shifted = shiftToAppTime(new Date());
  const year = shifted.getUTCFullYear();
  const month = String(shifted.getUTCMonth() + 1).padStart(2, "0");
  const day = String(shifted.getUTCDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getTodayLabel() {
  return shiftToAppTime(new Date()).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  });
}

function renderProfile(profile) {
  userName.textContent = profile.name || profile.username;
  userMeta.textContent = `@${profile.username} | credibility ${profile.credibilityScore ?? 0}`;
  profileHint.textContent = "Showing public profile data with the same HabTrack day rule as the main app.";
  todayLabel.textContent = getTodayLabel();
  profileView.classList.remove("hidden");
}

function renderTodayHabits(items) {
  todayHabitsContainer.innerHTML = "";

  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No public habits are scheduled for today.";
    todayHabitsContainer.appendChild(empty);
    return;
  }

  items.forEach((item) => {
    const card = document.createElement("article");
    card.className = "habit-card";

    const meta = document.createElement("div");
    const title = document.createElement("h3");
    title.textContent = item.title;
    const copy = document.createElement("p");
    copy.textContent = item.done
      ? `Completed for ${getTodayLabel()}`
      : `Planned for ${getTodayLabel()}`;
    meta.appendChild(title);
    meta.appendChild(copy);

    const badge = document.createElement("div");
    badge.className = `habit-action ${item.done ? "done" : "pending"}`;
    badge.textContent = item.done ? "Done" : "Pending";

    card.appendChild(meta);
    card.appendChild(badge);
    todayHabitsContainer.appendChild(card);
  });
}

async function loadUsername(username) {
  clearStatus();
  currentUsername = username.trim().replace(/^@+/, "").toLowerCase();

  if (!currentUsername) {
    showStatus("Enter a username first.", "error");
    return;
  }

  try {
    const profile = await publicRequest(`/users/public/${encodeURIComponent(currentUsername)}`);
    const habits = await publicRequest(
      `/activity/public/${encodeURIComponent(currentUsername)}/status?date=${getTodayKey()}`
    );

    renderProfile(profile);
    renderTodayHabits(habits);
    await storageSet({ habtrackLastUsername: currentUsername });
  } catch (error) {
    profileView.classList.add("hidden");
    todayHabitsContainer.innerHTML = "";
    showStatus(error.message, "error");
  }
}

usernameForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  await loadUsername(usernameInput.value);
});

refreshButton.addEventListener("click", async () => {
  if (!currentUsername) return;
  await loadUsername(currentUsername);
});

clearProfileButton.addEventListener("click", () => {
  currentUsername = "";
  usernameInput.value = "";
  profileView.classList.add("hidden");
  todayHabitsContainer.innerHTML = "";
  profileHint.textContent = "";
  todayLabel.textContent = "";
  clearStatus();
});

openSettingsButton.addEventListener("click", () => {
  extensionApi.runtime.openOptionsPage();
});

openWebAppButton.addEventListener("click", async () => {
  const { apiBase } = await getSettings();
  const appUrl = apiBase.includes("localhost")
    ? "http://localhost:5173"
    : "https://habit-tracker-frontend.vercel.app";

  extensionApi.tabs.create({ url: appUrl });
});

(async function initialize() {
  const { lastUsername } = await getSettings();
  if (lastUsername) {
    usernameInput.value = lastUsername;
    await loadUsername(lastUsername);
  }
})();
